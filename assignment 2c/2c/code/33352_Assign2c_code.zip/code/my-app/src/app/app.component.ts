import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Authentication Assignment 2c';
  displayName = '';
  displayEmail = '';
  displayPassword = '';
  getValue(name: string, email: string, password: string) {
    this.displayName = name;
    this.displayEmail = email;
    this.displayPassword = password;
  }
}
